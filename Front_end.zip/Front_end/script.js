document.addEventListener('DOMContentLoaded', () => {
    const prendaList = document.getElementById('prendaList');
    const prendaForm = document.getElementById('prendaForm');
    const prendaId = document.getElementById('prendaId');

    // Función para obtener todas las prendas
    async function fetchPrendas() {
        try {
            const response = await fetch('../API1/api/read.php');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const prendas = await response.json();
            prendaList.innerHTML = '';  // Limpiar lista antes de añadir

            prendas.forEach(prenda => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${sanitizeHTML(prenda.id_prenda)}</td>
                    <td>${sanitizeHTML(prenda.nombre_prenda)}</td>
                    <td>${sanitizeHTML(prenda.id_marca)}</td>
                    <td>${parseFloat(prenda.precio).toFixed(2)}</td>
                    <td>${parseInt(prenda.stock)}</td>
                    <td>
                        <button class="edit-btn" data-prenda-id="${prenda.id_prenda}">Editar</button>
                        <button class="delete-btn" data-prenda-id="${prenda.id_prenda}">Eliminar</button>
                    </td>
                `;
                prendaList.appendChild(tr);
            });
        } catch (error) {
            console.error('Error al cargar las prendas:', error);
            mostrarError('Error al cargar las prendas', error.message);
        }
    }

// Función para crear una nueva prenda
async function createPrenda(event) {
    event.preventDefault();

    const nombrePrenda = document.getElementById('nombre_prenda').value.trim();
    const idMarca = document.getElementById('id_marca').value.trim();
    const precioPrenda = document.getElementById('precio').value.trim();
    const stockPrenda = document.getElementById('stock').value.trim();

    // Validaciones básicas
    if (!nombrePrenda || !idMarca || !precioPrenda || !stockPrenda) {
        mostrarError('Error', 'Todos los campos son obligatorios');
        return;
    }

    const data = {
        nombre_prenda: nombrePrenda,
        id_marca: idMarca,
        precio: parseFloat(precioPrenda),
        stock: parseInt(stockPrenda)
    };

    try {
        const response = await fetch('../API1/api/create.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        if (result.success) {
            mostrarMensaje('Éxito', 'Prenda agregada con éxito');
            fetchPrendas();  // Actualiza la lista de prendas
            prendaForm.reset();  // Limpia el formulario
        } else {
            mostrarError('Error', result.error || 'Error al crear la prenda');
        }
    } catch (error) {
        console.error('Error al crear la prenda:', error);
        mostrarError('Error', 'No se pudo crear la prenda');
    }
}


    // Función para agregar o editar una prenda// Función para agregar o editar una prenda
async function savePrenda(event) {
    event.preventDefault();
    
    const id = prendaId.value.trim();
    const nombrePrenda = document.getElementById('nombre_prenda').value.trim();
    const idMarca = document.getElementById('id_marca').value.trim();
    const precioPrenda = document.getElementById('precio').value.trim();
    const stockPrenda = document.getElementById('stock').value.trim();
    
    // Validaciones básicas
    if (!nombrePrenda || !idMarca || !precioPrenda || !stockPrenda) {
        mostrarError('Error', 'Todos los campos son obligatorios');
        return;
    }
    
    const data = {
        id: id ? parseInt(id) : null, // Si el id está vacío, se asigna null
        nombre_prenda: nombrePrenda,
        id_marca: idMarca,
        precio: parseFloat(precioPrenda),
        stock: parseInt(stockPrenda)
    };

    let url, method;
    
    if (id) {
        // Si hay un id, es una actualización
        url = '../API1/api/update.php';
        method = 'POST';
    } else {
        // Si no hay id, es una creación (agregar nueva prenda)
        url = '../API1/api/create.php'; // Asegúrate de tener este endpoint en tu servidor
        method = 'POST';
    }

    try {
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
    
        const result = await response.json();
        if (result.success) {
            if (id) {
                mostrarMensaje('Éxito', 'Prenda actualizada con éxito');
            } else {
                mostrarMensaje('Éxito', 'Prenda agregada con éxito');
            }
            fetchPrendas();  // Actualiza la lista de prendas
            prendaForm.reset();  // Limpia el formulario
            prendaId.value = '';  // Resetear el ID
        } else {
            mostrarError('Error', result.error || 'Error al procesar la prenda');
        }
    } catch (error) {
        console.error('Error al procesar la prenda:', error);
        mostrarError('Error', 'No se pudo procesar la prenda');
    }
}

    
    // Función para editar una prenda (cargar datos en el formulario)
    function editPrenda(id) {
        // Buscar la fila de la tabla con el ID correspondiente
        const filaSeleccionada = document.querySelector(`button[data-prenda-id="${id}"]`).closest('tr');
        
        // Extraer datos de la fila
        const celdas = filaSeleccionada.getElementsByTagName('td');
        
        // Llenar el formulario con los datos de la fila
        prendaId.value = id;
        document.getElementById('nombre_prenda').value = celdas[1].textContent;
        document.getElementById('id_marca').value = celdas[2].textContent;
        document.getElementById('precio').value = celdas[3].textContent;
        document.getElementById('stock').value = celdas[4].textContent;
    }

    // Función para eliminar una prenda
    async function deletePrenda(id) {
        if (confirm("¿Estás seguro de que quieres eliminar esta prenda?")) {
            try {
                const response = await fetch(`../API1/api/delete.php?id=${id}`, { method: 'DELETE' });
                const data = await response.json();
                
                if (data.success) {
                    mostrarMensaje('Éxito', 'Prenda eliminada con éxito');
                    fetchPrendas();
                } else {
                    mostrarError('Error', data.error || 'No se pudo eliminar la prenda');
                }
            } catch (error) {
                console.error('Error al eliminar la prenda:', error);
                mostrarError('Error', 'No se pudo eliminar la prenda');
            }
        }
    }

    // Función para sanitizar HTML
    function sanitizeHTML(str) {
        if (str === null || str === undefined) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    // Funciones de notificación mejoradas
    function mostrarMensaje(titulo, mensaje) {
        alert(`${titulo}: ${mensaje}`);
        // Puedes reemplazar esta función con una implementación más moderna 
        // como SweetAlert, Toastr, o un modal personalizado
    }

    function mostrarError(titulo, mensaje) {
        console.error(`${titulo}: ${mensaje}`);
        alert(`${titulo}: ${mensaje}`);
        // Ídem comentario anterior sobre notificaciones
    }

    // Cargar las prendas al inicio
    fetchPrendas();

    // Manejar eventos del formulario
    prendaForm.addEventListener('submit', savePrenda);

    // Manejar eventos de edición y eliminación de prendas
    document.addEventListener('click', function(event) {
        const target = event.target;
        if (target.matches('.edit-btn')) {
            editPrenda(target.getAttribute('data-prenda-id'));
        }
        if (target.matches('.delete-btn')) {
            deletePrenda(target.getAttribute('data-prenda-id'));
        }
    });

    
    // Manejar evento de presionar Enter en el formulario
    prendaForm.addEventListener('keydown', function(event) {
        if (event.key === 'Enter' && event.target.form) {
            event.preventDefault(); // Evitar el envío automático del formulario
            savePrenda(event);
        }
    });
});
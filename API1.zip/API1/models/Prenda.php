<?php
class Prenda {
    private $conn;

    // Propiedades de la prenda
    public $id_prenda;
    public $nombre_prenda;
    public $id_marca;
    public $precio;
    public $stock;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Método para crear una nueva prenda
    public function create($nombre_prenda, $id_marca, $precio, $stock) {
        $query = "INSERT INTO Prendas (nombre_prenda, id_marca, precio, stock) 
                  VALUES (:nombre_prenda, :id_marca, :precio, :stock)";
        $stmt = $this->conn->prepare($query);

        // Vincular parámetros
        $stmt->bindParam(':nombre_prenda', $nombre_prenda);
        $stmt->bindParam(':id_marca', $id_marca);
        $stmt->bindParam(':precio', $precio);
        $stmt->bindParam(':stock', $stock);

        // Intentar ejecutar la consulta
        try {
            if ($stmt->execute()) {
                return true; // Si la ejecución es exitosa
            } else {
                return false; // Si no fue exitosa
            }
        } catch (PDOException $e) {
            error_log("Error al crear la prenda: " . $e->getMessage());
            return false;
        }
    }

    // Método para obtener todas las prendas
    public function getAll() {
        $query = "SELECT * FROM Prendas";
        $stmt = $this->conn->prepare($query);

        try {
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC); // Devolver los resultados como un array asociativo
        } catch (PDOException $e) {
            error_log("Error al obtener las prendas: " . $e->getMessage());
            return []; // Si ocurre un error, devolver un array vacío
        }
    }

    // Método para actualizar una prenda
    public function update($id, $nombre_prenda, $id_marca, $precio, $stock) {
        $query = "UPDATE Prendas SET 
                    nombre_prenda = :nombre_prenda, 
                    id_marca = :id_marca, 
                    precio = :precio, 
                    stock = :stock 
                  WHERE id_prenda = :id";

        $stmt = $this->conn->prepare($query);

        // Vincular parámetros
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':nombre_prenda', $nombre_prenda);
        $stmt->bindParam(':id_marca', $id_marca);
        $stmt->bindParam(':precio', $precio);
        $stmt->bindParam(':stock', $stock);

        // Intentar ejecutar la consulta
        try {
            if ($stmt->execute()) {
                return true; // Si la actualización fue exitosa
            } else {
                return false; // Si no fue exitosa
            }
        } catch (PDOException $e) {
            error_log("Error al actualizar la prenda: " . $e->getMessage());
            return false;
        }
    }

    // Método para eliminar una prenda
    public function delete($id) {
        try {
            // Preparar la consulta SQL
            $stmt = $this->conn->prepare("DELETE FROM Prendas WHERE id_prenda = :id");

            // Ejecutar la consulta con el parámetro
            $stmt->execute([':id' => $id]);

            // Verificar si se eliminó alguna fila
            if ($stmt->rowCount() > 0) {
                return true; // Eliminación exitosa
            } else {
                return false; // No se encontró el registro
            }
        } catch (PDOException $e) {
            // Manejo de errores
            error_log("Error al eliminar la prenda: " . $e->getMessage());
            return false; // Fallo en la eliminación
        }
    }
}
?>

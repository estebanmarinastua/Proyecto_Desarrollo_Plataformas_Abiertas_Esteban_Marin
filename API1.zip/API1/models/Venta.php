<?php
require_once 'config/database.php';

class Venta {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll() {
        $stmt = $this->conn->prepare("SELECT * FROM Ventas");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create($id_prenda, $fecha_venta, $cantidad) {
        $stmt = $this->conn->prepare("INSERT INTO Ventas (id_prenda, fecha_venta, cantidad) VALUES (:id_prenda, :fecha_venta, :cantidad)");
        $stmt->bindParam(':id_prenda', $id_prenda);
        $stmt->bindParam(':fecha_venta', $fecha_venta);
        $stmt->bindParam(':cantidad', $cantidad);
        return $stmt->execute();
    }
}
?>
const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();
const PORT = 5000;

// Middleware functions
const errorHandler = (err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal Server Error' });
};

const validatePrenda = (req, res, next) => {
  const { nombre_prenda, id_marca, precio, stock } = req.body;
  if (!nombre_prenda || !id_marca || precio == null || stock == null) {
    return res.status(400).json({ error: 'Todos los campos son obligatorios' });
  }
  next();
};

// Routes
app.use(cors());
app.use(express.json());

app.get('/api/prendas', (req, res) => {
  db.query('SELECT * FROM Prendas', (err, results) => {
    if (err) {
      return errorHandler(err, req, res);
    }
    res.json(results);
  });
});

app.post('/api/prendas', validatePrenda, (req, res) => {
  const { nombre_prenda, id_marca, precio, stock } = req.body;

  db.query('SELECT * FROM Marcas WHERE id_marca = ?', [id_marca], (err, results) => {
    if (err) {
      return errorHandler(err, req, res);
    }
    if (results.length === 0) {
      return res.status(400).json({ error: 'El id_marca no existe' });
    }

    db.query('INSERT INTO Prendas (nombre_prenda, id_marca, precio, stock) VALUES (?, ?, ?, ?)', 
      [nombre_prenda, id_marca, precio, stock], 
      (err, results) => {
        if (err) {
          return errorHandler(err, req, res);
        }
        res.status(201).json({ id_prenda: results.insertId });
      }
    );
  });
});

app.put('/api/prendas/:id', (req, res) => {
  const { id } = req.params;
  const { stock } = req.body;

  if (stock == null) {
    return res.status(400).json({ error: 'El stock es obligatorio' });
  }

  db.query('UPDATE Prendas SET stock = ? WHERE id_prenda = ?', [stock, id], (err, results) => {
    if (err) {
      return errorHandler(err, req, res);
    }
    if (results.affectedRows === 0) {
      return res.status(404).json({ error: 'Prenda no encontrada' });
    }
    res.json({ message: 'Stock actualizado' });
  });
});

app.delete('/api/prendas/:id', (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM Prendas WHERE id_prenda = ?', [id], (err, results) => {
    if (err) {
      return errorHandler(err, req, res);
    }
    if (results.affectedRows === 0) {
      return res.status(404).json({ error: 'Prenda no encontrada' });
    }
    res.json({ message: 'Prenda eliminada' });
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
// Obtener elementos del DOM
const prendasList = document.getElementById('prendas-list');
const addPrendaForm = document.getElementById('add-prenda-form');

// Función para obtener todas las prendas
async function fetchPrendas() {
    try {
        const response = await fetch('http://localhost:5000/api/prendas');
        if (!response.ok) throw new Error(`Error al obtener las prendas. Status: ${response.status}`);
        const prendas = await response.json();
        renderPrendas(prendas);
    } catch (error) {
        handleError('Hubo un problema al obtener las prendas', error);
    }
}

// Función para renderizar la lista de prendas
function renderPrendas(prendas) {
    prendasList.innerHTML = '';
    prendas.forEach(prenda => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${prenda.nombre_prenda}</td>
            <td>${prenda.id_marca}</td>
            <td>$${prenda.precio.toFixed(2)}</td>
            <td>${prenda.stock}</td>
            <td>
                <button onclick="editPrenda(${prenda.id_prenda})">Modificar</button>
                <button onclick="deletePrenda(${prenda.id_prenda})">Eliminar</button>
            </td>
        `;
        prendasList.appendChild(tr);
    });
}

// Agregar una nueva prenda
addPrendaForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const nombre_prenda = document.getElementById('nombre_prenda').value.trim();
    const id_marca = parseInt(document.getElementById('id_marca').value);
    const precio = parseFloat(document.getElementById('precio').value);
    const stock = parseInt(document.getElementById('stock').value);

    // Validar que el nombre no supere los 50 caracteres
    if (nombre_prenda.length > 50) {
        alert('El nombre de la prenda no puede exceder los 50 caracteres.');
        return;
    }

    // Validar que todos los campos estén correctamente llenados
    if (!nombre_prenda || isNaN(id_marca) || isNaN(precio) || isNaN(stock)) {
        alert('Por favor, rellene todos los campos correctamente.');
        return;
    }

    try {
        const response = await fetch('http://localhost:5000/api/prendas', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre_prenda, id_marca, precio, stock }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            console.error('Error del servidor al agregar:', errorData);
            throw new Error(errorData.error || 'Error al agregar la prenda');
        }

        fetchPrendas(); // Refrescar la lista
        addPrendaForm.reset(); // Limpiar el formulario
        alert('Prenda agregada con éxito.');
    } catch (error) {
        handleError('Hubo un problema al agregar la prenda', error);
    }
});


// Editar una prenda
async function editPrenda(id) {
    const newStock = prompt('Ingrese el nuevo stock:');
    if (!newStock || isNaN(parseInt(newStock))) {
        alert('Por favor, ingrese un stock válido.');
        return;
    }

    try {
        const response = await fetch(`http://localhost:5000/api/prendas/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ stock: parseInt(newStock) }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            console.error('Error del servidor al modificar:', errorData);
            throw new Error(errorData.error || 'Error al modificar la prenda');
        }

        fetchPrendas();
    } catch (error) {
        handleError('Hubo un problema al modificar la prenda', error);
    }
}

// Eliminar una prenda
async function deletePrenda(id) {
    if (!confirm('¿Estás seguro de que deseas eliminar esta prenda?')) return;

    try {
        const response = await fetch(`http://localhost:5000/api/prendas/${id}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            const errorData = await response.json();
            console.error('Error del servidor al eliminar:', errorData);
            throw new Error(errorData.error || 'Error al eliminar la prenda');
        }

        fetchPrendas();
    } catch (error) {
        handleError('Hubo un problema al eliminar la prenda', error);
    }
}

// Manejo de errores genéricos
function handleError(message, error) {
    console.error(`${message}:`, error);
    alert(`${message}: ${error.message}`);
}

// Obtener prendas al cargar la página
fetchPrendas(); // Llamado inicial para obtener las prendas
